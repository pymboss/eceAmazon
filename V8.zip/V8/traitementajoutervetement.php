<?php

session_start();


$id_ref = $_SESSION['id_ref'];
$sexe= isset($_POST["sexe"])? $_POST["sexe"] : "";
$type = isset($_POST["type"])? $_POST["type"] : "";
$taille= isset($_POST["taille"])? $_POST["taille"] : "";
$couleur= isset($_POST["couleur"])? $_POST["couleur"] : "";
$marque= isset($_POST["marque"])? $_POST["marque"] : "";


$database = "ece_amazon";

//connexion au serveur 
$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database);

//verifie si la bdd existe 

if ($db_found) {

    $sql = "INSERT INTO vetement (id_ref,sexe,type,taille,couleur,marque)
            VALUES('".$id_ref."','".$sexe."','".$type."','".$taille."','".$couleur."','".$marque."')";
    mysqli_query($db_handle, $sql);


        echo "Database found";
        echo $_SESSION['id_ref'];



}