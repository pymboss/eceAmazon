<?php

session_start();


$id_ref = $_SESSION['id_ref'];
$titre= isset($_POST["titre"])? $_POST["titre"] : "";
$artiste = isset($_POST["artiste"])? $_POST["artiste"] : "";
$genre = isset($_POST["genre"])? $_POST["genre"] : "";



$database = "ece_amazon";

//connexion au serveur 
$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database);

//verifie si la bdd existe 

if ($db_found) {

    $sql = "INSERT INTO musique(id_ref,titre,artiste,genre)
            VALUES('".$id_ref."','".$titre."','".$artiste."','".$genre."')";
    mysqli_query($db_handle, $sql);


        echo "Database found";
        echo $_SESSION['id_ref'];



}