<?php
   
session_start();


$mail= $_SESSION['email'];
$nom = isset($_POST["nom"])? $_POST["nom"] : "";
$description = isset($_POST["description"])? $_POST["description"] : "";
$photo= isset($_POST["photo"])? $_POST["photo"] : "";
$prix= isset($_POST["prix"])? $_POST["prix"] : "";
$categorie= isset($_POST["categorie"])? $_POST["categorie"] : "";
$quantite= isset($_POST["quantite"])? $_POST["quantite"] : "";





$database = "ece_amazon";

//connexion au serveur 
$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database);

//verifie si la bdd existe 

if ($db_found) {

    $sql = "INSERT INTO item(email_vendeur,nom,description,photo,prix,categorie,quantite)
            VALUES('".$mail."','".$nom."','".$description."','".$photo."','".$prix."','".$categorie."','".$quantite."')";
    mysqli_query($db_handle, $sql);

    $sql = "SELECT *  FROM item ";
        $result1 = mysqli_query($db_handle, $sql);

        while ($data = mysqli_fetch_assoc($result1)) {

        $_SESSION['id_ref'] = $data['id_ref'];
        }
}



else {
    echo "Database not found";
}


if($categorie == 'Musique')
	{
	
		header('Location: ajoutermusique.php'); 
	}

		if($categorie == 'Livre')
	{
	
		header('Location: ajouterlivre.php'); }

		if($categorie == 'Vetement')
	{
		header('Location: ajoutervetement.php'); }

		if($categorie == 'Sports et Loisirs')
	{
		header('Location: ajoutersport.php'); }






mysqli_close($db_handle);

?>