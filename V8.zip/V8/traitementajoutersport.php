<?php

session_start();


$id_ref = $_SESSION['id_ref'];
$type_sport= isset($_POST["type_sport"])? $_POST["type_sport"] : "";


$database = "ece_amazon";

//connexion au serveur 
$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database);

//verifie si la bdd existe 

if ($db_found) {

    $sql = "INSERT INTO sports_loisirs (id_ref,type_sport)
            VALUES('".$id_ref."','".$type_sport."')";
    mysqli_query($db_handle, $sql);


        echo "Database found";
        echo $_SESSION['id_ref'];



}