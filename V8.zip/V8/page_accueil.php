
<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
	<title>ECE AMAZON</title>
	<link rel="stylesheet" href="styles.css" type="text/css">
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript" src="js/grid-gallery.min.js"></script>
	<meta charset="utf-8">
	
</head>

<body>
<div id ="banniere">
<img src="img/bleu.jpg"  height="100" width="100%">

		</div>

	<div class="topnav">
	<nav>
		<ul>
			<img src="img/logo.png"  width="55" style="float: left; padding-top: 10px; padding-left: 15px;">
			<li class="menu-accueil"><a href="page_accueil.php">ACCUEIL</a></li>
			<li class="menu-categories"><a href="page_accueil.php">CATEGORIES</a>
				<ul class="submenu">
					<li><a href="musique.php">Musiques</a></li>
					<li><a href="sport.php">Sport et loisirs</a></li>
					<li><a href="vetement.php">Vêtements</a></li>
					<li><a href="livres.php">Livres</a></li>
				</ul>
			</li>

			<li class="menu-vente_Flash"><a href="vente_Flash.html">VENTES FLASH</a></li>
			<li class="menu-vendre"><a href="ajouterarticle.php">VENDRE</a></li>
			<li class="menu-admin"><a href="admin.html">ADMIN</a></li>
			<li class="menu-connexion" style="float: right;"><a href="connexion.php">CONNEXION</a></li>
			<li class="menu-connexion" style="float: right;"><a href="inscription.php">S'INSCRIRE</a></li>
			<li class="menu-connexion" style="float: right;"><a href="deconnexion.php">DECONNEXION</a></li>
           	<?php
           	if(isset($_SESSION['email']))
           	{
           		echo $_SESSION['email'];
           	}
			?>
			<li class="menu-compte"><a href="compte.php">COMPTE</a>
				<ul class="submenu">
					<li><a href="mesinfos.php">Mes Informations</a></li>
					<li><a href="monpanier.php">Panier</a></li>
</ul>


			</li>

		</ul>
	</nav>
 </div>

 <div id="slider" style="float:left;width:50%;margin-top: 10px;margin-left: 10px;">
  <figure>
    <img src="banniere.jpg" alt>
    <img src="banniere.jpg" alt>
    <img src="banniere.jpg" alt>
    <img src="banniere.jpg" alt>
    <img src="banniere.jpg" alt>
  </figure>
</div>

<div class="card" style="float:right;width:45%;">
	
	<center>
				<h3>Contactez nous</h3>

		<p>Chez ECEO,<br>
		Votre bonheur vous appartient</p></center>
	

</div>

</body>
</html>